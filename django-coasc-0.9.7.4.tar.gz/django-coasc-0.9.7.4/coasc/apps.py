from django.apps import AppConfig


class CoasCoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "coasc"
